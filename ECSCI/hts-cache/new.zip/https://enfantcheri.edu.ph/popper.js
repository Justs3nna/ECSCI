<!DOCTYPE html>
<html dir="ltr" lang="en-US"
	prefix="og: https://ogp.me/ns#" >
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    			 <meta property="og:title" content="Enfant Cheri Study Centre in Butuan City">
		<meta property="og:site_name" content="Enfant Cheri Study Centre">
		<meta property="og:url" content="https://enfantcheri.edu.ph/">
		<meta property="og:description" content="Trusted and Reliable School in Butuan City. We Offer Academic Program Preschool, Grade School, High School. ">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
		<meta property="og:type" content="article">
		<meta property="og:image" content="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/img/students-header.png"> 
    <meta name="google-site-verification" content="YEZwQ3acER1uPyYrnGpfcTDMRxhXO7QW4pclDT1MH1w" />
    <title>
    Not Found - Enfant Cheri Study Centre    </title>
   <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/spectre.css">
    <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/style.css">
    <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/aos.css">
    <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/animsition.css">
    <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/sidebar.css">
    <link rel="stylesheet" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/css/carousell.css">
    <link rel="shortcut icon" href="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/img/favicon.ico" type="image/x-icon" />
    <script src="https://kit.fontawesome.com/29e765d22c.js"></script>
    
		<!-- All in One SEO 4.2.0 -->
		<meta name="robots" content="noindex" />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"https:\/\/enfantcheri.edu.ph\/#website","url":"https:\/\/enfantcheri.edu.ph\/","name":"Enfant Cheri Study Centre","description":"Upholding Academic Excellence and Moral Standards","inLanguage":"en-US","publisher":{"@id":"https:\/\/enfantcheri.edu.ph\/#organization"}},{"@type":"Organization","@id":"https:\/\/enfantcheri.edu.ph\/#organization","name":"Enfant Cheri Study Centre","url":"https:\/\/enfantcheri.edu.ph\/"},{"@type":"BreadcrumbList","@id":"https:\/\/enfantcheri.edu.ph\/popper.js\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/enfantcheri.edu.ph\/#listItem","position":1,"item":{"@type":"WebPage","@id":"https:\/\/enfantcheri.edu.ph\/","name":"Home","description":"Trusted and Reliable School in Butuan City. We Offer Academic Program Preschool, Grade School, High School.","url":"https:\/\/enfantcheri.edu.ph\/"},"nextItem":"https:\/\/enfantcheri.edu.ph\/popper.js\/#listItem"},{"@type":"ListItem","@id":"https:\/\/enfantcheri.edu.ph\/popper.js\/#listItem","position":2,"item":{"@type":"WebPage","@id":"https:\/\/enfantcheri.edu.ph\/popper.js\/","name":"Not Found","url":"https:\/\/enfantcheri.edu.ph\/popper.js\/"},"previousItem":"https:\/\/enfantcheri.edu.ph\/#listItem"}]}]}
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//www.google.com' />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/enfantcheri.edu.ph\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.5"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://enfantcheri.edu.ph/wp-includes/css/dist/block-library/style.min.css?ver=6.5.5' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://enfantcheri.edu.ph/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.6' type='text/css' media='all' />
<link rel="https://api.w.org/" href="https://enfantcheri.edu.ph/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://enfantcheri.edu.ph/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.5" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>  </head>
  <body>
    <header class="navbar">
      <div class="col-12 header-stripe"></div>
      <div class="container grid-xl">
        <div class="columns">
          <div class="col-6">
            <img src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/img/logo.png" alt="" class="logo">
          </div>
          <div class="col-6">
            <nav class="navbar-section" data-sidebarClass="navbar-inverse">
              <button type="button" class="navbar-toggler left-navbar-toggle" data-toggle="collapse" data-target="#myNavbar" aria-expanded="false" aria-label="Toggle navigation">
              <span class="icon-menu">MENU</span>
              </button>
              
              <div class="navbar-collapse" id="enfantcheri_menu">
                <div id="enfantcheri_menu" class="menu-header_menu_enfant_cheri-container"><ul id="menu-header_menu_enfant_cheri" class="navbar-section"><li id="menu-item-5" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-5"><a title="Home" href="https://enfantcheri.edu.ph/" class="nav-link">Home</a></li>
<li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-26 dropdown"><a title="About us" href="#" data-toggle="dropdown" class="nav-link" aria-haspopup="true">About us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-83" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-83"><a title="History" href="https://enfantcheri.edu.ph/history/" class="nav-link">History</a></li>
	<li id="menu-item-86" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-86"><a title="Mission / Vision" href="https://enfantcheri.edu.ph/mission-vision/" class="nav-link">Mission / Vision</a></li>
	<li id="menu-item-89" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-89"><a title="Milestone" href="https://enfantcheri.edu.ph/milestone/" class="nav-link">Milestone</a></li>
</ul>
</li>
<li id="menu-item-99" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-99"><a title="Academic Program" href="https://enfantcheri.edu.ph/academic-program/" class="nav-link">Academic Program</a></li>
<li id="menu-item-240" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-240 dropdown"><a title="The Cherian Pen" href="#" data-toggle="dropdown" class="nav-link" aria-haspopup="true">The Cherian Pen <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-28" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-28"><a title="Current News" href="https://enfantcheri.edu.ph/news/" class="nav-link">Current News</a></li>
	<li id="menu-item-251" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-251"><a title="SY2018-2019" href="https://enfantcheri.edu.ph/sy2018-2019/" class="nav-link">SY2018-2019</a></li>
</ul>
</li>
<li id="menu-item-29" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29"><a title="Contact us" href="https://enfantcheri.edu.ph/contact-us/" class="nav-link">Contact us</a></li>
</ul></div>              </div><!--- end of collapse navbar-->
            </nav><!-- end of nav-->
          </div><!-- end of column 6-->
          </div><!-- end of columns-->
          </div><!-- end of container-->
        </header><div class="container grid-xl">
	<div class="columns">
		<div class="col-12 error404">
	     <h4>ERROR 404 <br/>PAGE NOT FOUND</</h4>
	  </div>
	</div>
</div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
<path fill="#04550A" fill-opacity="1" d="M0,224L360,160L720,160L1080,160L1440,64L1440,320L1080,320L720,320L360,320L0,320Z" class = "slant-footer-divider"></path>
</svg>
<footer>
<div class="footer-container">
	<div class="container grid-xl">
		<div class="columns">
			<div class="col-6 col-md-12 section-news">
				<h3>News</h3>
								<h4 class="news-title"><a title="ECSCI declares winners of CSG election" href="https://enfantcheri.edu.ph/ecsci-declares-winners-of-csg-election/" rel="bookmark">ECSCI declares winners of CSG election</a></h4>
				<span class="news-date">enfantadmin&nbsp;on&nbsp;21st September 2020</span><br/>
				<p>Rych B. Beluan and Maria Ioanna Naive The Cherians voted in a new set of student government officers&nbsp;through remote online voting on the morning of Sept. 9. The election results</br></br><a class="read-more" href="https://enfantcheri.edu.ph/ecsci-declares-winners-of-csg-election/">→  Read More</a></p>
							</div>
			<div class="col-6 col-md-12 section-contact-us">
				<h3>Contact us here</h3>
				<ul>
					<li>P-1  Upper Doongan, Butuan City</li>
					<li>342 - 3241  /  225 - 4378</li>
				</ul>
			</div>
			<img src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/img/footer-fern.png" alt="" class="footer-fern">
		</div>
	</div>
	<div class="micro-footer">
		<div class="container grid-xl">
			<div class="columns">
				
				<div class="col-12">
					<span>©2025 Enfant Cheri Study  Center, Inc</span>
				</div>
				
			</div>
		</div>
	</div>
</div>
</footer>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/jquery-3.2.1.min.js"></script>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/rellax.min.js"></script>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/siema.min.js"></script>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/sidebar.js"></script>
<script src="https://enfantcheri.edu.ph/wp-content/themes/enfantcheri-theme/assets/js/custom.js"></script>


</body>
</html>



